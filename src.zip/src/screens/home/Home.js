import React from 'react';
import Header from '../../common/Header';
import LoginModal from '../../common/loginModal';

const Home = () => {

    const [open, setOpen] = React.useState(false);

    const handleOpen = () => {
        setOpen(true);
      };
    
      const handleClose = () => {
        setOpen(false);
      };

    return (
        <div>
            <Header title="Hello" buttonName="Login" showBookShow={true} onBookShowClick={handleOpen} />
            <LoginModal openModal={open} handleClose={handleClose}/>
        </div>

    )
}



export default Home