import React from 'react';
import { BrowserRouter as Router, Route  } from 'react-router-dom'
import Home from './home/Home';

const Controller = () => {
    return(
        <Router>
            <div  className="main-container">
                <Route
                    exact
                    path="/"
                    render={(props) => <Home {...props}/>}
                />
            </div>
        </Router>
    )
}

export default Controller